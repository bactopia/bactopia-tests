{
  "version": "1.2",
  "dbname": "SRR2838702.fna",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "Assembled contigs for SRR2838702",
  "number-of-letters": 159095,
  "number-of-sequences": 80,
  "last-updated": "2025-02-25T21:39:00",
  "number-of-volumes": 1,
  "bytes-total": 86174,
  "bytes-to-cache": 40907,
  "files": [
    "SRR2838702.fna.ndb",
    "SRR2838702.fna.nhr",
    "SRR2838702.fna.nin",
    "SRR2838702.fna.not",
    "SRR2838702.fna.nsq",
    "SRR2838702.fna.ntf",
    "SRR2838702.fna.nto"
  ]
}
